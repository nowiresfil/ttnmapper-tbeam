/*

Credentials file

*/

#pragma once

// Only one of these settings must be defined
//#define USE_ABP
#define USE_OTAA

#ifdef USE_ABP

// TBEAM-1
    // LoRaWAN NwkSKey, network session key
    static const u1_t PROGMEM NWKSKEY[16] = { 0x37, 0xDC, 0xA8, 0x9C, 0x29, 0x6A, 0x6B, 0xB3, 0x75, 0xA3, 0xE0, 0x6F, 0x8D, 0xB9, 0xEE, 0x19 };
    // LoRaWAN AppSKey, application session key
    static const u1_t PROGMEM APPSKEY[16] = { 0x9C, 0xCE, 0xB4, 0xA4, 0x79, 0x30, 0x32, 0xE6, 0x6D, 0x72, 0x25, 0xCA, 0x3A, 0x70, 0x98, 0xA4 };
    // LoRaWAN end-device address (DevAddr)
    // This has to be unique for every node
    static const u4_t DEVADDR = 0x26041454;

/*/ TBEAM-2
    // LoRaWAN NwkSKey, network session key
    static const u1_t PROGMEM NWKSKEY[16] = { 0x69, 0x17, 0x43, 0x8C, 0x9B, 0x4E, 0x95, 0x97, 0x18, 0xBE, 0xBB, 0x89, 0x72, 0x66, 0xA8, 0x3F };
    // LoRaWAN AppSKey, application session key
    static const u1_t PROGMEM APPSKEY[16] = { 0x8F, 0xDB, 0x7E, 0x50, 0x35, 0xA4, 0xAE, 0x38, 0x80, 0x65, 0xCC, 0x96, 0xE5, 0x2E, 0xF3, 0xE0 };
    // LoRaWAN end-device address (DevAddr)
    // This has to be unique for every node
    static const u4_t DEVADDR = 0x26041744;
*/
#endif

#ifdef USE_OTAA

    // This EUI must be in little-endian format, so least-significant-byte
    // first. When copying an EUI from ttnctl output, this means to reverse
    // the bytes. For TTN issued EUIs the last bytes should be 0x00, 0x00,
    // 0x00.
    static const u1_t PROGMEM APPEUI[8]  = { 0xBA, 0xCF, 0x01, 0xD0, 0x7E, 0xD5, 0xB3, 0x70 };

    // This should also be in little endian format, see above.
    static const u1_t PROGMEM DEVEUI[8]  = { 0xAC, 0x83, 0x61, 0x59, 0x2D, 0x40, 0x9E, 0x00 };

    // This key should be in big endian format (or, since it is not really a
    // number but a block of memory, endianness does not really apply). In
    // practice, a key taken from ttnctl can be copied as-is.
    // The key shown here is the semtech default key.
    static const u1_t PROGMEM APPKEY[16] = { 0xC5, 0x07, 0x8A, 0xD3, 0x8E, 0x8F, 0x29, 0xF9, 0xC4, 0xDB, 0x9D, 0xCB, 0xD4, 0xDD, 0xAF, 0x53 };

#endif
